package org.lumenvision.photoncompat.sim;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Quaternion;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.networktables.BooleanPublisher;
import edu.wpi.first.networktables.BooleanSubscriber;
import edu.wpi.first.networktables.DoubleArrayPublisher;
import edu.wpi.first.networktables.DoubleArraySubscriber;
import edu.wpi.first.networktables.DoublePublisher;
import edu.wpi.first.networktables.IntegerPublisher;
import edu.wpi.first.networktables.IntegerSubscriber;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.networktables.NetworkTablesJNI;
import edu.wpi.first.networktables.PubSubOption;
import edu.wpi.first.networktables.RawPublisher;
import edu.wpi.first.networktables.StringPublisher;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.lumenvision.lib.LumenCoprocessor;
import org.lumenvision.lib.LumenDetector;
import org.lumenvision.lib.LumenGraph;
import org.lumenvision.photoncompat.PhotonCamera;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Random;

/**
 * A simulated LumenVision AprilTag camera: given its pose in the field and the tags around it, it projects them through a pinhole model
 * and publishes the same NetworkTables topics the coprocessor's AprilTag detector would, so {@link org.lumenvision.lib.LumenAprilTagDetector}
 * / {@code PhotonCamera} and the pose estimators read it unchanged. Usually driven by a {@link VisionSystemSim}; {@link #update(long, Pose3d, Collection)} can be called directly.
 *
 * <p>Targets are detected when they face the camera and all their corners are inside the image with enough pixel area. Poses are
 * ground truth (zero ambiguity); the properties' pixel noise moves the reported corners only. Targets do not occlude each other.
 * Multi-tag and constrained results are published when their inputs are there, exactly as the coprocessor does.
 */
public class PhotonCameraSim implements AutoCloseable {
    // every open simulated camera by NT instance and root table: they share the one .graph topic, so each publishes all of their nodes
    private static final Map<String, List<PhotonCameraSim>> OPEN = new HashMap<>();

    private static final Map<String, Integer> NEXT_ID = new HashMap<>();
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final LumenDetector<?> camera;
    // node ids and tables as the coprocessor would give them; fixed for the life of the simulated camera
    private final int cameraId;
    private final String cameraTable;
    private final String detectorTable;
    private final SimCameraProperties properties;
    private final Random random = new Random();

    private final RawPublisher resultPub;
    private final DoubleArrayPublisher intrinsicsPub;
    private final DoubleArrayPublisher distortionPub;
    private final DoublePublisher heartbeatPub;
    private final StringPublisher versionPub;
    private final BooleanPublisher enabledStatusPub;
    private final StringPublisher graphPub;
    private final IntegerPublisher protocolPub;
    private final IntegerPublisher fpsStatusPub;
    private final IntegerPublisher ledStatusPub;
    private final BooleanSubscriber enabledConfigSub;
    private final IntegerSubscriber fpsConfigSub;
    private final IntegerSubscriber ledConfigSub;
    private final DoubleArraySubscriber seedSub;
    private final DoubleArraySubscriber mountSub;

    private Pose3d layoutOrigin = new Pose3d();
    private double maxSightRangeMeters = Double.POSITIVE_INFINITY;
    private boolean enabled = true;
    private long sequence = 0;
    private long heartbeat = 0;
    private long nextFrameMicros = 0;
    private long lastPublishedMicros = -1;

    public PhotonCameraSim(LumenDetector<?> camera, SimCameraProperties properties) {
        this.camera = camera;
        this.properties = properties.copy();

        NetworkTableInstance instance = camera.getNetworkTableInstance();
        String root = "/" + camera.getRootTable() + "/";
        // the camera and its detector carry the same name, so, as the coprocessor does, the detector's table is numbered apart
        synchronized (OPEN) {
            List<PhotonCameraSim> sims = OPEN.computeIfAbsent(graphKey(), k -> new ArrayList<>());
            // a second simulation of the same detector publishes into the first one's nodes rather than numbering new ones
            PhotonCameraSim same = sims.stream().filter(sim -> sim.camera == camera).findFirst().orElse(null);
            if (same != null) {
                cameraId = same.cameraId;
                cameraTable = same.cameraTable;
                detectorTable = same.detectorTable;
            } else {
                int next = NEXT_ID.getOrDefault(graphKey(), 1);
                cameraId = next;
                NEXT_ID.put(graphKey(), next + 2);
                Set<String> used = new HashSet<>();
                for (PhotonCameraSim sim : sims) {
                    used.add(sim.cameraTable);
                    used.add(sim.detectorTable);
                }
                cameraTable = uniqueTable(camera.getName(), cameraId, used);
                detectorTable = uniqueTable(camera.getName(), cameraId + 1, used);
            }
            sims.add(this);
        }
        String base = root + detectorTable + "/";
        resultPub = instance.getRawTopic(base + "result").publish("raw", PubSubOption.sendAll(true), PubSubOption.keepDuplicates(true));
        intrinsicsPub = instance.getDoubleArrayTopic(base + "cameraIntrinsics").publish();
        distortionPub = instance.getDoubleArrayTopic(base + "cameraDistortion").publish();
        heartbeatPub = instance.getDoubleTopic(root + "heartbeat").publish();
        versionPub = instance.getStringTopic(root + ".version").publish();
        enabledStatusPub = instance.getBooleanTopic(base + "status/enabled").publish();
        graphPub = instance.getStringTopic(root + ".graph").publish();
        protocolPub = instance.getIntegerTopic(root + ".protocol").publish();
        fpsStatusPub = instance.getIntegerTopic(base + "status/fpsLimit").publish();
        ledStatusPub = instance.getIntegerTopic(root + "status/ledMode").publish();
        enabledConfigSub = instance.getBooleanTopic(base + "config/enabled").subscribe(true);
        fpsConfigSub = instance.getIntegerTopic(base + "config/fpsLimit").subscribe(-1);
        ledConfigSub = instance.getIntegerTopic(root + "config/ledMode").subscribe(-1);
        seedSub = instance.getDoubleArrayTopic(base + "config/constrainedSeed").subscribe(new double[0]);
        mountSub = instance.getDoubleArrayTopic(base + "config/robotToCamera").subscribe(new double[0]);
    }

    // the coprocessor's rule (NetworkTablesControlService.ComputeNodeTables): the sanitised name, with the id appended when another node has it
    private static String uniqueTable(String name, int id, Set<String> used) {
        String table = LumenDetector.tableName(name);
        if (table.isEmpty()) table = String.valueOf(id);
        else if (!used.add(table)) table = table + "-" + id;
        used.add(table);
        return table;
    }

    private String graphKey() {
        return camera.getNetworkTableInstance().getHandle() + "/" + camera.getRootTable();
    }

    // each open camera on this NT instance and root as a camera node (odd id) feeding its detector (the next id), which carries the
    // camera's name as the coprocessor names it
    private String graphJson() {
        // built by a JSON encoder: a camera name may hold a quote or backslash, which would otherwise empty the graph for every detector
        ObjectNode root = MAPPER.createObjectNode();
        ArrayNode nodes = root.putArray("nodes");
        synchronized (OPEN) {
            List<PhotonCameraSim> sims = OPEN.getOrDefault(graphKey(), List.of(this));
            Set<Integer> listed = new HashSet<>();
            for (PhotonCameraSim sim : sims) {
                if (!listed.add(sim.cameraId)) continue;
                String name = sim.camera.getName();
                ObjectNode cameraNode = nodes.addObject();
                cameraNode.put("id", sim.cameraId).put("name", name).put("table", sim.cameraTable).put("kind", "Camera")
                        .put("enabled", true).putNull("input");
                ObjectNode detectorNode = nodes.addObject();
                detectorNode.put("id", sim.cameraId + 1).put("name", name).put("table", sim.detectorTable)
                        .put("kind", LumenGraph.APRILTAG_DETECTOR).put("enabled", sim.enabledConfigSub.get()).put("input", sim.cameraId);
            }
        }
        return root.toString();
    }

    public PhotonCameraSim(PhotonCamera camera, SimCameraProperties properties) {
        this(camera.getLumenDetector(), properties);
    }

    public LumenDetector<?> getCamera() {
        return camera;
    }

    public SimCameraProperties getProperties() {
        return properties;
    }

    /** Seeds the noise and latency jitter so a run is repeatable. */
    public void setRandomSeed(long seed) {
        random.setSeed(seed);
    }

    /** Targets farther than this are not detected (default unlimited). */
    public void setMaxSightRange(double meters) {
        this.maxSightRangeMeters = meters;
    }

    /** A disabled camera publishes nothing, as if unplugged. */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /** The frame of the field layout the coprocessor would solve in; {@link VisionSystemSim#addAprilTags} sets this. */
    public void setLayoutOrigin(Pose3d layoutOrigin) {
        this.layoutOrigin = layoutOrigin;
    }

    /** Runs the camera at the current time; see {@link #update(long, Pose3d, Collection)}. */
    public boolean update(Pose3d cameraPoseInField, Collection<VisionTargetSim> targets) {
        return update(NetworkTablesJNI.now(), cameraPoseInField, targets);
    }

    /**
     * Captures a frame if the camera's frame interval has elapsed and publishes its result, stamped with the capture time
     * ({@code nowMicros} minus a latency sample).
     *
     * @param nowMicros the NT clock, in microseconds
     * @param cameraPoseInField the camera's pose in the same frame as the targets
     * @return whether a result was published
     */
    public boolean update(long nowMicros, Pose3d cameraPoseInField, Collection<VisionTargetSim> targets) {
        if (!enabled) return false;
        publishStatus();
        if (nowMicros < nextFrameMicros) return false;

        double interval = properties.getFrameIntervalMs();
        long fpsLimit = fpsConfigSub.get();
        if (fpsLimit > 0) interval = Math.max(interval, 1000.0 / fpsLimit);
        nextFrameMicros = nowMicros + Math.round(interval * 1000.0);

        // a stopped detector publishes nothing
        if (!enabledConfigSub.get()) return false;
        List<SimResultEncoder.Target> detected = detect(cameraPoseInField, targets);

        long latencyMicros = Math.round(Math.max(0.0, properties.getAvgLatencyMs() + random.nextGaussian() * properties.getLatencyStdDevMs()) * 1000.0);
        long captureMicros = Math.max(1, nowMicros - latencyMicros);
        if (captureMicros <= lastPublishedMicros) captureMicros = lastPublishedMicros + 1; // NT topics keep timestamps non-decreasing
        lastPublishedMicros = captureMicros;

        List<Integer> multiTagIds = new ArrayList<>();
        SimResultEncoder.MultiTag multiTag = null;
        long fiducialCount = detected.stream().filter(t -> t.fiducialId() >= 0).count();
        if (fiducialCount >= 2) {
            for (SimResultEncoder.Target target : detected) if (target.fiducialId() >= 0) multiTagIds.add(target.fiducialId());
            multiTag = new SimResultEncoder.MultiTag(layoutOrigin.plus(new Transform3d(new Pose3d(), cameraPoseInField)), 0.0);
        }

        SimResultEncoder.Constrained constrained = null;
        double[] seed = seedSub.get();
        double[] mount = mountSub.get();
        if (fiducialCount >= 1 && seed.length == 3 && mount.length == 7) {
            Transform3d robotToCamera = new Transform3d(new Translation3d(mount[0], mount[1], mount[2]),
                    new Rotation3d(new Quaternion(mount[3], mount[4], mount[5], mount[6])));
            Pose3d robotInLayout = layoutOrigin.plus(new Transform3d(new Pose3d(), cameraPoseInField.transformBy(robotToCamera.inverse())));
            Pose2d floor = robotInLayout.toPose2d();
            constrained = new SimResultEncoder.Constrained(floor.getX(), floor.getY(), floor.getRotation().getRadians(), 0.0, (int) fiducialCount);
        }

        byte[] packet = SimResultEncoder.encode(++sequence, latencyMicros, multiTag, multiTagIds, constrained, detected);
        resultPub.set(packet, captureMicros);
        return true;
    }

    private void publishStatus() {
        heartbeatPub.set(heartbeat++);
        versionPub.set(LumenDetector.getLibraryVersion());
        intrinsicsPub.set(properties.getIntrinsics());
        distortionPub.set(properties.getDistCoeffs());
        enabledStatusPub.set(enabledConfigSub.get());
        protocolPub.set(LumenCoprocessor.PROTOCOL_VERSION);
        graphPub.set(graphJson());
        fpsStatusPub.set(fpsConfigSub.get());
        ledStatusPub.set(ledConfigSub.get());
    }

    private List<SimResultEncoder.Target> detect(Pose3d cameraPose, Collection<VisionTargetSim> targets) {
        List<SimResultEncoder.Target> detected = new ArrayList<>();
        for (VisionTargetSim target : targets) {
            SimResultEncoder.Target result = project(cameraPose, target);
            if (result != null) detected.add(result);
        }
        return detected;
    }

    // camera-frame (X forward, Y left, Z up) position of a field point
    private static Translation3d toCameraFrame(Pose3d cameraPose, Translation3d fieldPoint) {
        return fieldPoint.minus(cameraPose.getTranslation()).rotateBy(cameraPose.getRotation().unaryMinus());
    }

    private double[] pixel(Translation3d inCamera) {
        return new double[] {
                properties.getCx() - properties.getFx() * (inCamera.getY() / inCamera.getX()),
                properties.getCy() - properties.getFy() * (inCamera.getZ() / inCamera.getX()) };
    }

    private SimResultEncoder.Target project(Pose3d cameraPose, VisionTargetSim target) {
        Pose3d targetPose = target.getPose();
        TargetModel model = target.getModel();
        Translation3d cameraPosition = cameraPose.getTranslation();
        if (cameraPosition.getDistance(targetPose.getTranslation()) > maxSightRangeMeters) return null;

        if (model.isPlanar()) {
            // a flat target is only seen from its front: the face normal (X) must point towards the camera
            Translation3d normal = new Translation3d(1, 0, 0).rotateBy(targetPose.getRotation());
            Translation3d toCamera = cameraPosition.minus(targetPose.getTranslation());
            if (normal.getX() * toCamera.getX() + normal.getY() * toCamera.getY() + normal.getZ() * toCamera.getZ() <= 0) return null;
        }

        List<Translation3d> fieldVertices = model.getFieldVertices(targetPose);
        double[][] pixels = new double[fieldVertices.size()][];
        for (int i = 0; i < pixels.length; i++) {
            Translation3d inCamera = toCameraFrame(cameraPose, fieldVertices.get(i));
            if (inCamera.getX() <= 1e-6) return null; // behind or at the lens
            pixels[i] = pixel(inCamera);
        }

        double[] corners;
        if (model.isPlanar()) {
            corners = new double[8];
            for (int i = 0; i < 4; i++) {
                corners[i * 2] = pixels[i][0];
                corners[i * 2 + 1] = pixels[i][1];
            }
        } else {
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            for (double[] p : pixels) {
                minX = Math.min(minX, p[0]);
                maxX = Math.max(maxX, p[0]);
                minY = Math.min(minY, p[1]);
                maxY = Math.max(maxY, p[1]);
            }
            corners = new double[] { minX, maxY, maxX, maxY, maxX, minY, minX, minY };
        }

        // the coprocessor needs every corner in the image to decode a tag
        for (int i = 0; i < 4; i++) {
            if (corners[i * 2] < 0 || corners[i * 2] > properties.getResWidth() || corners[i * 2 + 1] < 0 || corners[i * 2 + 1] > properties.getResHeight()) return null;
        }

        double areaPixels = polygonArea(corners);
        if (areaPixels < properties.getMinTargetAreaPixels()) return null;

        // the corner noise is applied after visibility, as sensor noise would be
        double[] noisy = corners.clone();
        for (int i = 0; i < 4; i++) {
            double magnitude = Math.max(0.0, properties.getAvgErrorPixels() + random.nextGaussian() * properties.getErrorStdDevPixels());
            double direction = random.nextDouble() * 2.0 * Math.PI;
            noisy[i * 2] += magnitude * Math.cos(direction);
            noisy[i * 2 + 1] += magnitude * Math.sin(direction);
        }

        double centreX = 0, centreY = 0;
        for (int i = 0; i < 4; i++) {
            centreX += noisy[i * 2] / 4.0;
            centreY += noisy[i * 2 + 1] / 4.0;
        }
        double yaw = Math.toDegrees(Math.atan((properties.getCx() - centreX) / properties.getFx()));
        double pitch = Math.toDegrees(Math.atan((properties.getCy() - centreY) / properties.getFy()));
        double areaPercent = 100.0 * areaPixels / ((double) properties.getResWidth() * properties.getResHeight());

        double[] rect = new double[8];
        double skew = minAreaRect(noisy, rect);

        return new SimResultEncoder.Target(target.getFiducialId(), yaw, pitch, areaPercent, skew,
                new Transform3d(cameraPose, targetPose), noisy, rect);
    }

    private static double polygonArea(double[] corners) {
        double sum = 0;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            sum += corners[i * 2] * corners[j * 2 + 1] - corners[j * 2] * corners[i * 2 + 1];
        }
        return Math.abs(sum) / 2.0;
    }

    /**
     * The smallest rectangle around four points, found by trying each edge direction. Writes its corners (x0,y0..x3,y3) to
     * {@code rectOut} and returns the rotation of its first edge in degrees, in [0, 90).
     */
    static double minAreaRect(double[] corners, double[] rectOut) {
        double bestArea = Double.MAX_VALUE;
        double bestAngle = 0;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            double angle = Math.atan2(corners[j * 2 + 1] - corners[i * 2 + 1], corners[j * 2] - corners[i * 2]);
            double c = Math.cos(angle), s = Math.sin(angle);
            double minU = Double.MAX_VALUE, maxU = -Double.MAX_VALUE, minV = Double.MAX_VALUE, maxV = -Double.MAX_VALUE;
            for (int k = 0; k < 4; k++) {
                double u = corners[k * 2] * c + corners[k * 2 + 1] * s;
                double v = -corners[k * 2] * s + corners[k * 2 + 1] * c;
                minU = Math.min(minU, u);
                maxU = Math.max(maxU, u);
                minV = Math.min(minV, v);
                maxV = Math.max(maxV, v);
            }
            double area = (maxU - minU) * (maxV - minV);
            if (area < bestArea) {
                bestArea = area;
                bestAngle = angle;
                double[][] box = { { minU, minV }, { maxU, minV }, { maxU, maxV }, { minU, maxV } };
                for (int k = 0; k < 4; k++) {
                    rectOut[k * 2] = box[k][0] * c - box[k][1] * s;
                    rectOut[k * 2 + 1] = box[k][0] * s + box[k][1] * c;
                }
            }
        }
        double degrees = Math.toDegrees(bestAngle) % 90.0;
        return degrees < 0 ? degrees + 90.0 : degrees;
    }

    @Override
    public void close() {
        synchronized (OPEN) {
            List<PhotonCameraSim> sims = OPEN.get(graphKey());
            if (sims != null) {
                sims.remove(this);
                if (sims.isEmpty()) {
                    OPEN.remove(graphKey());
                    NEXT_ID.remove(graphKey());
                }
            }
        }
        for (AutoCloseable closeable : new AutoCloseable[] {
                resultPub, intrinsicsPub, distortionPub, heartbeatPub, versionPub, enabledStatusPub, graphPub, protocolPub, fpsStatusPub,
                ledStatusPub, enabledConfigSub, fpsConfigSub, ledConfigSub, seedSub, mountSub }) {
            try {
                closeable.close();
            } catch (Exception ignored) {
                // closing a topic handle cannot fail in a way the caller could act on
            }
        }
    }
}
