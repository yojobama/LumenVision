package org.lumenvision.lib;

import edu.wpi.first.networktables.BooleanPublisher;
import edu.wpi.first.networktables.BooleanSubscriber;
import edu.wpi.first.networktables.IntegerPublisher;
import edu.wpi.first.networktables.NetworkTableInstance;

/**
 * A node of the coprocessor's graph, addressed by the name its topics are published under. Any node can be started and stopped and asked
 * to save its latest frame; {@link LumenAprilTagDetector} and {@link LumenObjectDetector} add results.
 *
 * <p>Writes go to {@code <rootTable>/<node>/config/*} and the state in effect is read back from {@code status/*}.
 */
public class LumenNode implements AutoCloseable {
    private final NetworkTableInstance instance;
    private final String rootTable;
    private final String name;

    // not final: a node whose table the coprocessor numbered apart from another's is rebound once the graph says so
    private String table;
    private BooleanPublisher enabledPub;
    private IntegerPublisher snapshotPub;
    private BooleanSubscriber enabledSub;
    private BooleanPublisher recordingPub;
    private BooleanSubscriber recordingSub;
    private long snapshotCount;

    /**
     * @param instance the NetworkTableInstance to use (injectable for simulation)
     * @param rootTable must match the coprocessor's NetworkTablesConfig.rootTable (default "lumenvision")
     * @param name the NT table the node's topics are under (see {@link LumenGraph.Node#getTable()})
     */
    public LumenNode(NetworkTableInstance instance, String rootTable, String name) {
        this.instance = instance;
        this.rootTable = rootTable;
        this.name = name;
        bindNodeTopics(tableName(name));
    }

    private void bindNodeTopics(String table) {
        this.table = table;
        String base = "/" + rootTable + "/" + table + "/";
        enabledPub = instance.getBooleanTopic(base + "config/enabled").publish();
        snapshotPub = instance.getIntegerTopic(base + "config/snapshot").publish();
        enabledSub = instance.getBooleanTopic(base + "status/enabled").subscribe(true);
        recordingPub = instance.getBooleanTopic(base + "config/recording").publish();
        recordingSub = instance.getBooleanTopic(base + "status/recording").subscribe(false);
    }

    /** The NT table name a node's topics are published under: its name with characters outside {@code [A-Za-z0-9_.-]} replaced by {@code _}. */
    public static String tableName(String nodeName) {
        StringBuilder out = new StringBuilder(nodeName.length());
        for (int i = 0; i < nodeName.length(); i++) {
            char c = nodeName.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.';
            out.append(ok ? c : '_');
        }
        return out.toString();
    }

    /** The NT table the node's topics are under now: {@link #tableName} of its name until the graph names another. */
    protected final String getTable() {
        return table;
    }

    /** Moves the node's control topics to another table (see {@link LumenGraph.Node#getTable()}); a subclass rebinds its own as well. */
    protected void retarget(String newTable) {
        if (newTable.equals(table)) return;
        closeNodeTopics();
        bindNodeTopics(newTable);
    }

    public String getName() {
        return name;
    }

    /** The NetworkTables instance this node reads and writes (the simulation publishes into the same one). */
    public NetworkTableInstance getNetworkTableInstance() {
        return instance;
    }

    /** The NT root table, e.g. "lumenvision". */
    public String getRootTable() {
        return rootTable;
    }

    /** Starts or stops the node; the choice is kept across coprocessor restarts. */
    public void setEnabled(boolean enabled) {
        enabledPub.set(enabled);
    }

    /** Whether the coprocessor reports the node running; true until it has reported. */
    public boolean isEnabled() {
        return enabledSub.get();
    }

    /** Starts or stops recording this node's frames on the coprocessor (annotated for a detector, raw for a camera). */
    public void setRecording(boolean recording) {
        recordingPub.set(recording);
    }

    public void startRecording() {
        setRecording(true);
    }

    public void stopRecording() {
        setRecording(false);
    }

    /** Whether the coprocessor reports a recording running on this node; false until it has reported. */
    public boolean isRecording() {
        return recordingSub.get();
    }

    /** Saves the node's latest frame on the coprocessor (the annotated frame for a detector, the raw one for a camera). */
    public void takeSnapshot() {
        snapshotPub.set(++snapshotCount);
    }

    @Override
    public void close() {
        closeNodeTopics();
    }

    private void closeNodeTopics() {
        for (AutoCloseable closeable : new AutoCloseable[] { enabledPub, snapshotPub, enabledSub, recordingPub, recordingSub }) {
            try {
                closeable.close();
            } catch (Exception ignored) {
                // closing a topic handle cannot fail in a way the caller could act on
            }
        }
    }
}
